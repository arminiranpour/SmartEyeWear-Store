using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SmartEyewearStore.Views.Store
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
